#ifndef IMAGE_TESTS_H
#define IMAGE_TESTS_H

char *hourly_imagescale_logic(const uint64_t max, const int rate);
void add_image_tests(Suite *s);

#endif
