#ifndef PERCENTILE_TESTS_H
#define PERCENTILE_TESTS_H

void add_percentile_tests(Suite *s);

#endif
